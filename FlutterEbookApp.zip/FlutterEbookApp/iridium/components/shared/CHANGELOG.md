## 0.1.3

* Fix error when loading some epub

## 0.1.2

* Migration to null-safety

## 0.1.1

* Removed unused dependency

## 0.1.0

* Contains these main API: Container, Fetcher, MediaType, Opds, Publication and Zip
