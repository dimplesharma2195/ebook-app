# mno_lcp_dart

## Flutter LCP implementation

This package provides a DART LCP layer. 

Important: The prebuilt [Edrlab](http://edrlab.org) `liblcp` native libs are wrapped through FFI in a small separate companion project: https://github.com/Mantano/mno_lcp_native_without_libs.
