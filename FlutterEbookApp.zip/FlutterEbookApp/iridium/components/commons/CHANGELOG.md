## 0.1.2

* Migration to null-safety

## 0.1.1

* Fix naming errors

## 0.1.0

* Contains common utilities:
	* Href: Uri generation
	* Try: contains either a success or a failure
	* JSONable: extensions to manipulate JSON structure
	* Extensions for String, ByteData, FileSystemEntity and Uri
