## 0.1.1

* Improve documentation

## 0.1.0

* Include Streamer that has the capability to parse CBZ, epub, image, PDF and Readium publications
* Support null-safety
