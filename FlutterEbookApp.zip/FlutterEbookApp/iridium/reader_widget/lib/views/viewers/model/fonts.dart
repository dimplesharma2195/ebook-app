class Fonts {
  static const List<String> googleFonts = [
    "Original",
    "PT Serif",
    "Roboto",
    "Source Sans Pro",
    "Vollkorn"
  ];
}
